package com.md.wordt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WordtApplicationTests {

	@Test
	void contextLoads() {
	}

}
